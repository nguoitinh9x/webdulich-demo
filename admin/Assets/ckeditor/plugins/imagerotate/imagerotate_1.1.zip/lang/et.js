﻿CKEDITOR.plugins.setLang('imagerotate', 'et', {
  rotateRight: 'Pööra päripäeva',
  rotateLeft: 'Pööra vastupäeva'
});
